Test 1:
The purpose of test one is to to so how the priority queue handles the planes when multiple call for change in emergency status due to low fuel

Test 2:
The purpose of test 2 is to check how the priority queue handles having one time step with all planes entering the simulation at the same time with different status

Test 3:
The purpose of test 3 is to help identify how the queues will behave for longer periods of time stamp intervals

Test 4:
The purpose of test 4 is to check how the priority queue manages when both arrival and departure individually

Test 5:
The purpose of test 5 is to check how priority queue may choose which plane when there are many emergencies during shorter period of time and also a different starting period. 